import React, { useState } from 'react'
import { NeonButton } from '../registry/components/neon-button'
import { GradientButton } from '../registry/components/gradient-button'
import { ToggleSwitch } from '../registry/components/toggle-switch'
import { LoadingSpinner } from '../registry/components/loading-spinner'
import { FloatingInput } from '../registry/components/floating-input'
import { AnimatedCard, GlowCard, FlipCard } from '../registry/components/animated-card'
import { MorphingButton, LiquidButton, ElasticButton, GlitchButton } from '../registry/components/morphing-button'
import { Mail, User, Lock, Search, Heart, Star, Zap } from 'lucide-react'

// Neon Button Examples
export const NeonButtonExamples = () => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Neon Button Variants</h3>
        <div className="flex flex-wrap gap-4">
          <NeonButton variant="neon-blue">Blue Neon</NeonButton>
          <NeonButton variant="neon-purple">Purple Neon</NeonButton>
          <NeonButton variant="neon-green">Green Neon</NeonButton>
          <NeonButton variant="neon-pink">Pink Neon</NeonButton>
          <NeonButton variant="neon-cyan">Cyan Neon</NeonButton>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">Sizes</h3>
        <div className="flex flex-wrap gap-4 items-center">
          <NeonButton size="sm" variant="neon-blue">Small</NeonButton>
          <NeonButton size="default" variant="neon-purple">Default</NeonButton>
          <NeonButton size="lg" variant="neon-green">Large</NeonButton>
        </div>
      </div>
    </div>
  )
}

// Gradient Button Examples
export const GradientButtonExamples = () => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Gradient Variants</h3>
        <div className="flex flex-wrap gap-4">
          <GradientButton variant="sunset">Sunset</GradientButton>
          <GradientButton variant="ocean">Ocean</GradientButton>
          <GradientButton variant="forest">Forest</GradientButton>
          <GradientButton variant="purple">Purple</GradientButton>
          <GradientButton variant="rainbow">Rainbow</GradientButton>
          <GradientButton variant="gold">Gold</GradientButton>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">With Animation</h3>
        <div className="flex flex-wrap gap-4">
          <GradientButton variant="sunset" animated={true}>Animated Sunset</GradientButton>
          <GradientButton variant="ocean" animated={false}>Static Ocean</GradientButton>
        </div>
      </div>
    </div>
  )
}

// Toggle Switch Examples
export const ToggleSwitchExamples = () => {
  const [switches, setSwitches] = useState({
    default: false,
    neon: false,
    gradient: false,
    minimal: false
  })

  const handleSwitchChange = (key, value) => {
    setSwitches(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Switch Variants</h3>
        <div className="space-y-4">
          <ToggleSwitch 
            variant="default" 
            label="Default Switch"
            checked={switches.default}
            onCheckedChange={(value) => handleSwitchChange('default', value)}
          />
          <ToggleSwitch 
            variant="neon" 
            label="Neon Switch"
            checked={switches.neon}
            onCheckedChange={(value) => handleSwitchChange('neon', value)}
          />
          <ToggleSwitch 
            variant="gradient" 
            label="Gradient Switch"
            checked={switches.gradient}
            onCheckedChange={(value) => handleSwitchChange('gradient', value)}
          />
          <ToggleSwitch 
            variant="minimal" 
            label="Minimal Switch"
            checked={switches.minimal}
            onCheckedChange={(value) => handleSwitchChange('minimal', value)}
          />
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">Sizes</h3>
        <div className="space-y-4">
          <ToggleSwitch size="sm" label="Small" />
          <ToggleSwitch size="default" label="Default" />
          <ToggleSwitch size="lg" label="Large" />
        </div>
      </div>
    </div>
  )
}

// Loading Spinner Examples
export const LoadingSpinnerExamples = () => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Spinner Variants</h3>
        <div className="flex flex-wrap gap-8 items-center">
          <div className="text-center">
            <LoadingSpinner variant="default" />
            <p className="text-sm mt-2">Default</p>
          </div>
          <div className="text-center">
            <LoadingSpinner variant="dots" />
            <p className="text-sm mt-2">Dots</p>
          </div>
          <div className="text-center">
            <LoadingSpinner variant="pulse" />
            <p className="text-sm mt-2">Pulse</p>
          </div>
          <div className="text-center">
            <LoadingSpinner variant="bars" />
            <p className="text-sm mt-2">Bars</p>
          </div>
          <div className="text-center">
            <LoadingSpinner variant="ring" />
            <p className="text-sm mt-2">Ring</p>
          </div>
          <div className="text-center">
            <LoadingSpinner variant="gradient" />
            <p className="text-sm mt-2">Gradient</p>
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">Colors & Sizes</h3>
        <div className="flex flex-wrap gap-4 items-center">
          <LoadingSpinner size="sm" color="blue" />
          <LoadingSpinner size="default" color="purple" />
          <LoadingSpinner size="lg" color="green" />
          <LoadingSpinner size="xl" color="red" />
        </div>
      </div>
    </div>
  )
}

// Floating Input Examples
export const FloatingInputExamples = () => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Input Variants</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FloatingInput 
            variant="default" 
            label="Email Address" 
            type="email"
            icon={Mail}
          />
          <FloatingInput 
            variant="neon" 
            label="Username" 
            type="text"
            icon={User}
          />
          <FloatingInput 
            variant="minimal" 
            label="Password" 
            type="password"
            icon={Lock}
          />
          <FloatingInput 
            variant="glass" 
            label="Search" 
            type="search"
            icon={Search}
          />
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">States</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FloatingInput 
            variant="default" 
            label="Success Input" 
            success="Looks good!"
            defaultValue="valid@email.com"
          />
          <FloatingInput 
            variant="default" 
            label="Error Input" 
            error="This field is required"
          />
        </div>
      </div>
    </div>
  )
}

// Animated Card Examples
export const AnimatedCardExamples = () => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Card Animations</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatedCard variant="hover-lift">
            <div className="text-center">
              <Heart className="w-8 h-8 mx-auto mb-2 text-red-500" />
              <h3 className="font-semibold">Hover Lift</h3>
              <p className="text-sm text-gray-600">Lifts up on hover</p>
            </div>
          </AnimatedCard>
          
          <AnimatedCard variant="hover-tilt">
            <div className="text-center">
              <Star className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
              <h3 className="font-semibold">Hover Tilt</h3>
              <p className="text-sm text-gray-600">Tilts on hover</p>
            </div>
          </AnimatedCard>
          
          <AnimatedCard variant="hover-glow" glowColor="blue">
            <div className="text-center">
              <Zap className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <h3 className="font-semibold">Hover Glow</h3>
              <p className="text-sm text-gray-600">Glows on hover</p>
            </div>
          </AnimatedCard>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">Special Cards</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <GlowCard glowColor="purple" intensity="high">
            <div className="text-center">
              <h3 className="font-semibold text-lg mb-2">Glow Card</h3>
              <p className="text-gray-600">A card with beautiful glow effects</p>
            </div>
          </GlowCard>
          
          <FlipCard
            frontContent={
              <div className="text-center">
                <h3 className="font-semibold text-lg">Front Side</h3>
                <p className="text-gray-600">Hover to flip</p>
              </div>
            }
            backContent={
              <div className="text-center">
                <h3 className="font-semibold text-lg">Back Side</h3>
                <p>Hidden content revealed!</p>
              </div>
            }
          />
        </div>
      </div>
    </div>
  )
}

// Morphing Button Examples
export const MorphingButtonExamples = () => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Morphing Variants</h3>
        <div className="flex flex-wrap gap-4">
          <MorphingButton variant="expand">Expand</MorphingButton>
          <MorphingButton variant="slide">Slide</MorphingButton>
          <MorphingButton variant="rotate">Rotate</MorphingButton>
          <MorphingButton variant="bounce">Bounce</MorphingButton>
          <MorphingButton variant="flip">Flip</MorphingButton>
          <MorphingButton variant="pulse">Pulse</MorphingButton>
          <MorphingButton variant="morph">Morph</MorphingButton>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">Special Buttons</h3>
        <div className="flex flex-wrap gap-4">
          <LiquidButton>Liquid Effect</LiquidButton>
          <ElasticButton>Elastic</ElasticButton>
          <GlitchButton>Glitch</GlitchButton>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">Morph Text</h3>
        <div className="flex flex-wrap gap-4">
          <MorphingButton 
            variant="expand" 
            morphTo="Expanded!"
          >
            Hover Me
          </MorphingButton>
          <MorphingButton 
            variant="slide" 
            morphTo="Slided!"
          >
            Slide Text
          </MorphingButton>
        </div>
      </div>
    </div>
  )
}

