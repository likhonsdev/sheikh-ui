import React, { useState } from "react"
import { Button } from "../registry/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../registry/components/card"
import { Badge } from "../registry/components/badge"
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "../registry/components/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../registry/components/tabs"
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "../registry/components/accordion"
import { Progress } from "../registry/components/progress"
import { Switch } from "../registry/components/switch"
import {
  Users,
  Activity,
  TrendingUp,
  DollarSign,
  Package,
  ShoppingCart,
  Star,
  Clock,
  CheckCircle,
  AlertCircle,
  Settings,
  Bell,
  Shield,
  Zap,
  Database,
  Code,
  Palette,
  Globe,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Download,
  Upload,
  Edit,
  Trash2,
  Eye,
  MoreHorizontal
} from "lucide-react"

// Table Examples
function TableExamples() {
  const invoices = [
    {
      invoice: "INV001",
      paymentStatus: "Paid",
      totalAmount: "$250.00",
      paymentMethod: "Credit Card",
      customer: "John Doe",
      date: "2024-01-15"
    },
    {
      invoice: "INV002",
      paymentStatus: "Pending",
      totalAmount: "$150.00",
      paymentMethod: "PayPal",
      customer: "Jane Smith",
      date: "2024-01-16"
    },
    {
      invoice: "INV003",
      paymentStatus: "Unpaid",
      totalAmount: "$350.00",
      paymentMethod: "Bank Transfer",
      customer: "Bob Johnson",
      date: "2024-01-17"
    },
    {
      invoice: "INV004",
      paymentStatus: "Paid",
      totalAmount: "$450.00",
      paymentMethod: "Credit Card",
      customer: "Alice Brown",
      date: "2024-01-18"
    },
    {
      invoice: "INV005",
      paymentStatus: "Paid",
      totalAmount: "$550.00",
      paymentMethod: "PayPal",
      customer: "Charlie Wilson",
      date: "2024-01-19"
    }
  ]

  const getStatusBadge = (status) => {
    switch (status) {
      case "Paid":
        return <Badge variant="success">Paid</Badge>
      case "Pending":
        return <Badge variant="warning">Pending</Badge>
      case "Unpaid":
        return <Badge variant="error">Unpaid</Badge>
      default:
        return <Badge variant="default">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Data Table</h3>
        <Card>
          <CardHeader>
            <CardTitle>Recent Invoices</CardTitle>
            <CardDescription>A list of your recent invoices and their payment status.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableCaption>A list of your recent invoices.</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Invoice</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((invoice) => (
                  <TableRow key={invoice.invoice}>
                    <TableCell className="font-medium">{invoice.invoice}</TableCell>
                    <TableCell>{invoice.customer}</TableCell>
                    <TableCell>{getStatusBadge(invoice.paymentStatus)}</TableCell>
                    <TableCell>{invoice.paymentMethod}</TableCell>
                    <TableCell>{invoice.date}</TableCell>
                    <TableCell className="text-right">{invoice.totalAmount}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Simple Table</h3>
        <Card>
          <CardContent className="p-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Salary</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">John Doe</TableCell>
                  <TableCell>Software Engineer</TableCell>
                  <TableCell><Badge variant="success">Active</Badge></TableCell>
                  <TableCell className="text-right">$75,000</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Jane Smith</TableCell>
                  <TableCell>Product Manager</TableCell>
                  <TableCell><Badge variant="success">Active</Badge></TableCell>
                  <TableCell className="text-right">$85,000</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Bob Johnson</TableCell>
                  <TableCell>Designer</TableCell>
                  <TableCell><Badge variant="warning">On Leave</Badge></TableCell>
                  <TableCell className="text-right">$65,000</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Tabs Examples
function TabsExamples() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Basic Tabs</h3>
        <Tabs defaultValue="account" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="password">Password</TabsTrigger>
          </TabsList>
          <TabsContent value="account" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>
                  Make changes to your account here. Click save when you're done.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Name</label>
                  <input 
                    className="w-full px-3 py-2 border geist-border rounded-md geist-bg-primary geist-text-primary"
                    defaultValue="John Doe"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <input 
                    className="w-full px-3 py-2 border geist-border rounded-md geist-bg-primary geist-text-primary"
                    defaultValue="john@example.com"
                  />
                </div>
                <Button>Save changes</Button>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="password" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Password Settings</CardTitle>
                <CardDescription>
                  Change your password here. After saving, you'll be logged out.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Current password</label>
                  <input 
                    type="password"
                    className="w-full px-3 py-2 border geist-border rounded-md geist-bg-primary geist-text-primary"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">New password</label>
                  <input 
                    type="password"
                    className="w-full px-3 py-2 border geist-border rounded-md geist-bg-primary geist-text-primary"
                  />
                </div>
                <Button>Save password</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Dashboard Tabs</h3>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 geist-text-secondary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$45,231.89</div>
                  <p className="text-xs geist-text-secondary">+20.1% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Subscriptions</CardTitle>
                  <Users className="h-4 w-4 geist-text-secondary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">+2350</div>
                  <p className="text-xs geist-text-secondary">+180.1% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sales</CardTitle>
                  <ShoppingCart className="h-4 w-4 geist-text-secondary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">+12,234</div>
                  <p className="text-xs geist-text-secondary">+19% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Now</CardTitle>
                  <Activity className="h-4 w-4 geist-text-secondary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">+573</div>
                  <p className="text-xs geist-text-secondary">+201 since last hour</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle>Analytics</CardTitle>
                <CardDescription>View your analytics and performance metrics.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="geist-text-secondary">Analytics content would go here...</p>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Reports</CardTitle>
                <CardDescription>Generate and view your reports.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="geist-text-secondary">Reports content would go here...</p>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>Manage your notification preferences.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="geist-text-secondary">Notifications content would go here...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Accordion Examples
function AccordionExamples() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">FAQ Accordion</h3>
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger>Is it accessible?</AccordionTrigger>
            <AccordionContent>
              Yes. It adheres to the WAI-ARIA design pattern and is built with Radix UI primitives.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-2">
            <AccordionTrigger>Is it styled?</AccordionTrigger>
            <AccordionContent>
              Yes. It comes with default styles that match the Geist design system, but you can customize it to your needs.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-3">
            <AccordionTrigger>Is it animated?</AccordionTrigger>
            <AccordionContent>
              Yes. It's animated by default, but you can disable it if you prefer.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Features Accordion</h3>
        <Accordion type="multiple" className="w-full">
          <AccordionItem value="performance">
            <AccordionTrigger>
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Performance
              </div>
            </AccordionTrigger>
            <AccordionContent>
              Our components are built with performance in mind, using modern React patterns and optimized bundle sizes.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="accessibility">
            <AccordionTrigger>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Accessibility
              </div>
            </AccordionTrigger>
            <AccordionContent>
              All components follow WCAG guidelines and are built with Radix UI primitives for maximum accessibility.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="customization">
            <AccordionTrigger>
              <div className="flex items-center gap-2">
                <Palette className="h-4 w-4" />
                Customization
              </div>
            </AccordionTrigger>
            <AccordionContent>
              Every component can be fully customized with CSS variables and Tailwind classes to match your design system.
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="developer-experience">
            <AccordionTrigger>
              <div className="flex items-center gap-2">
                <Code className="h-4 w-4" />
                Developer Experience
              </div>
            </AccordionTrigger>
            <AccordionContent>
              Built with TypeScript, excellent IntelliSense support, and comprehensive documentation for the best DX.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  )
}

// Progress Examples
function ProgressExamples() {
  const [progress, setProgress] = useState(13)

  React.useEffect(() => {
    const timer = setTimeout(() => setProgress(66), 500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Basic Progress</h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="w-full" />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Multiple Progress Bars</h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>CPU Usage</span>
              <span>45%</span>
            </div>
            <Progress value={45} className="w-full" />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Memory Usage</span>
              <span>78%</span>
            </div>
            <Progress value={78} className="w-full" />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Storage Usage</span>
              <span>23%</span>
            </div>
            <Progress value={23} className="w-full" />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Network Usage</span>
              <span>91%</span>
            </div>
            <Progress value={91} className="w-full" />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Project Progress</h3>
        <Card>
          <CardHeader>
            <CardTitle>Project Status</CardTitle>
            <CardDescription>Track the progress of your current projects</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Website Redesign</span>
                <Badge variant="success">On Track</Badge>
              </div>
              <Progress value={85} className="w-full" />
              <p className="text-xs geist-text-secondary mt-1">85% complete</p>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Mobile App</span>
                <Badge variant="warning">Behind</Badge>
              </div>
              <Progress value={42} className="w-full" />
              <p className="text-xs geist-text-secondary mt-1">42% complete</p>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">API Development</span>
                <Badge variant="info">In Progress</Badge>
              </div>
              <Progress value={67} className="w-full" />
              <p className="text-xs geist-text-secondary mt-1">67% complete</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Switch Examples
function SwitchExamples() {
  const [notifications, setNotifications] = useState(true)
  const [marketing, setMarketing] = useState(false)
  const [analytics, setAnalytics] = useState(true)
  const [darkMode, setDarkMode] = useState(false)

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Basic Switch</h3>
        <div className="flex items-center space-x-2">
          <Switch id="airplane-mode" />
          <label htmlFor="airplane-mode" className="text-sm font-medium">
            Airplane mode
          </label>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Settings Panel</h3>
        <Card>
          <CardHeader>
            <CardTitle>Preferences</CardTitle>
            <CardDescription>Manage your account preferences and settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Push Notifications</label>
                <p className="text-xs geist-text-secondary">
                  Receive push notifications about your account activity
                </p>
              </div>
              <Switch 
                checked={notifications} 
                onCheckedChange={setNotifications}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Marketing Emails</label>
                <p className="text-xs geist-text-secondary">
                  Receive emails about new products and features
                </p>
              </div>
              <Switch 
                checked={marketing} 
                onCheckedChange={setMarketing}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Analytics</label>
                <p className="text-xs geist-text-secondary">
                  Help us improve by sharing anonymous usage data
                </p>
              </div>
              <Switch 
                checked={analytics} 
                onCheckedChange={setAnalytics}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label className="text-sm font-medium">Dark Mode</label>
                <p className="text-xs geist-text-secondary">
                  Switch to dark theme
                </p>
              </div>
              <Switch 
                checked={darkMode} 
                onCheckedChange={setDarkMode}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Feature Toggles</h3>
        <Card>
          <CardHeader>
            <CardTitle>Feature Flags</CardTitle>
            <CardDescription>Enable or disable experimental features</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 border geist-border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full geist-bg-secondary flex items-center justify-center">
                  <Zap className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Fast Mode</p>
                  <p className="text-xs geist-text-secondary">Experimental performance improvements</p>
                </div>
              </div>
              <Switch />
            </div>
            <div className="flex items-center justify-between p-4 border geist-border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full geist-bg-secondary flex items-center justify-center">
                  <Database className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Advanced Analytics</p>
                  <p className="text-xs geist-text-secondary">Detailed usage analytics and insights</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between p-4 border geist-border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full geist-bg-secondary flex items-center justify-center">
                  <Globe className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Global CDN</p>
                  <p className="text-xs geist-text-secondary">Serve content from global edge locations</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export {
  TableExamples,
  TabsExamples,
  AccordionExamples,
  ProgressExamples,
  SwitchExamples,
}

