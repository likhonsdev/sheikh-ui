import React, { useState } from "react"
import { Button } from "../registry/components/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../registry/components/card"
import { Input, InputGroup, InputLeftElement, InputRightElement } from "../registry/components/input"
import { Badge } from "../registry/components/badge"
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "../registry/components/dialog"
import {
  Search,
  Mail,
  Lock,
  User,
  Star,
  Heart,
  Download,
  Settings,
  Plus,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  Calendar,
  Clock,
  MapPin,
  Phone,
  Globe,
  Shield,
  Zap,
  Award,
  TrendingUp,
  Users,
  Activity
} from "lucide-react"

// Button Examples
function ButtonExamples() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Button Variants</h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="default">Default</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="outline">Outline</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="link">Link</Button>
          <Button variant="destructive">Destructive</Button>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Geist Button Variants</h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="geist">Geist</Button>
          <Button variant="geist-filled">Geist Filled</Button>
          <Button variant="geist-ghost">Geist Ghost</Button>
          <Button variant="geist-outline">Geist Outline</Button>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Button Sizes</h3>
        <div className="flex flex-wrap items-center gap-3">
          <Button size="sm">Small</Button>
          <Button size="default">Default</Button>
          <Button size="lg">Large</Button>
          <Button size="icon"><Settings className="h-4 w-4" /></Button>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Geist Button Sizes</h3>
        <div className="flex flex-wrap items-center gap-3">
          <Button variant="geist" size="geist-sm">Small</Button>
          <Button variant="geist" size="geist-md">Medium</Button>
          <Button variant="geist" size="geist-lg">Large</Button>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Buttons with Icons</h3>
        <div className="flex flex-wrap gap-3">
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
          <Button variant="outline">
            <Plus className="mr-2 h-4 w-4" />
            Add Item
          </Button>
          <Button variant="geist">
            <Star className="mr-2 h-4 w-4" />
            Star
          </Button>
          <Button variant="destructive">
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Button States</h3>
        <div className="flex flex-wrap gap-3">
          <Button>Normal</Button>
          <Button disabled>Disabled</Button>
          <Button variant="outline" disabled>Disabled Outline</Button>
        </div>
      </div>
    </div>
  )
}

// Card Examples
function CardExamples() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Card Variants</h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card variant="default">
            <CardHeader>
              <CardTitle>Default Card</CardTitle>
              <CardDescription>This is a default card with standard styling.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="geist-text-secondary">Card content goes here.</p>
            </CardContent>
          </Card>

          <Card variant="secondary">
            <CardHeader>
              <CardTitle>Secondary Card</CardTitle>
              <CardDescription>This card uses secondary background.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="geist-text-secondary">Card content goes here.</p>
            </CardContent>
          </Card>

          <Card variant="outline">
            <CardHeader>
              <CardTitle>Outline Card</CardTitle>
              <CardDescription>This card has a prominent border.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="geist-text-secondary">Card content goes here.</p>
            </CardContent>
          </Card>

          <Card variant="elevated">
            <CardHeader>
              <CardTitle>Elevated Card</CardTitle>
              <CardDescription>This card has enhanced shadow.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="geist-text-secondary">Card content goes here.</p>
            </CardContent>
          </Card>

          <Card variant="ghost">
            <CardHeader>
              <CardTitle>Ghost Card</CardTitle>
              <CardDescription>This card has no border or shadow.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="geist-text-secondary">Card content goes here.</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Feature Cards</h3>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <div className="w-12 h-12 rounded-lg geist-bg-secondary flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 geist-text-primary" />
              </div>
              <CardTitle>Fast Performance</CardTitle>
              <CardDescription>
                Built with performance in mind using modern React patterns and optimized bundle size.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 rounded-lg geist-bg-secondary flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 geist-text-primary" />
              </div>
              <CardTitle>Accessible</CardTitle>
              <CardDescription>
                Built on Radix UI primitives with full keyboard navigation and screen reader support.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="w-12 h-12 rounded-lg geist-bg-secondary flex items-center justify-center mb-4">
                <Settings className="w-6 h-6 geist-text-primary" />
              </div>
              <CardTitle>Customizable</CardTitle>
              <CardDescription>
                Copy and paste components with full control over styling and behavior.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Stats Cards</h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 geist-text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">45,231</div>
              <p className="text-xs geist-text-secondary">
                +20.1% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenue</CardTitle>
              <TrendingUp className="h-4 w-4 geist-text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$12,234</div>
              <p className="text-xs geist-text-secondary">
                +19% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Now</CardTitle>
              <Activity className="h-4 w-4 geist-text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">573</div>
              <p className="text-xs geist-text-secondary">
                +201 since last hour
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion</CardTitle>
              <Award className="h-4 w-4 geist-text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12.5%</div>
              <p className="text-xs geist-text-secondary">
                +2.5% from last month
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// Input Examples
function InputExamples() {
  const [showPassword, setShowPassword] = useState(false)

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Input Variants</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Default Input</label>
            <Input placeholder="Enter your email" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Filled Input</label>
            <Input variant="filled" placeholder="Enter your name" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Ghost Input</label>
            <Input variant="ghost" placeholder="Search..." />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Outline Input</label>
            <Input variant="outline" placeholder="Enter text" />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Input Sizes</h3>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Small Input</label>
            <Input size="sm" placeholder="Small input" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Default Input</label>
            <Input size="default" placeholder="Default input" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Large Input</label>
            <Input size="lg" placeholder="Large input" />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Input with Icons</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Search</label>
            <InputGroup>
              <InputLeftElement>
                <Search className="h-4 w-4" />
              </InputLeftElement>
              <Input placeholder="Search..." className="pl-10" />
            </InputGroup>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Email</label>
            <InputGroup>
              <InputLeftElement>
                <Mail className="h-4 w-4" />
              </InputLeftElement>
              <Input type="email" placeholder="Enter your email" className="pl-10" />
            </InputGroup>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Password</label>
            <InputGroup>
              <InputLeftElement>
                <Lock className="h-4 w-4" />
              </InputLeftElement>
              <Input 
                type={showPassword ? "text" : "password"} 
                placeholder="Enter your password" 
                className="pl-10 pr-10" 
              />
              <InputRightElement>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-4 w-4"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </InputRightElement>
            </InputGroup>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium geist-text-primary">Username</label>
            <InputGroup>
              <InputLeftElement>
                <User className="h-4 w-4" />
              </InputLeftElement>
              <Input placeholder="Enter username" className="pl-10" />
            </InputGroup>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Form Example</h3>
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Create Account</CardTitle>
            <CardDescription>Enter your details to create a new account.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium geist-text-primary">Full Name</label>
              <InputGroup>
                <InputLeftElement>
                  <User className="h-4 w-4" />
                </InputLeftElement>
                <Input placeholder="John Doe" className="pl-10" />
              </InputGroup>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium geist-text-primary">Email</label>
              <InputGroup>
                <InputLeftElement>
                  <Mail className="h-4 w-4" />
                </InputLeftElement>
                <Input type="email" placeholder="john@example.com" className="pl-10" />
              </InputGroup>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium geist-text-primary">Password</label>
              <InputGroup>
                <InputLeftElement>
                  <Lock className="h-4 w-4" />
                </InputLeftElement>
                <Input type="password" placeholder="••••••••" className="pl-10" />
              </InputGroup>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full">Create Account</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

// Badge Examples
function BadgeExamples() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Badge Variants</h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="default">Default</Badge>
          <Badge variant="secondary">Secondary</Badge>
          <Badge variant="destructive">Destructive</Badge>
          <Badge variant="outline">Outline</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Geist Badge Variants</h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="geist">Geist</Badge>
          <Badge variant="geist-filled">Geist Filled</Badge>
          <Badge variant="geist-outline">Geist Outline</Badge>
          <Badge variant="geist-ghost">Geist Ghost</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Status Badges</h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="success">Success</Badge>
          <Badge variant="warning">Warning</Badge>
          <Badge variant="error">Error</Badge>
          <Badge variant="info">Info</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Badge Sizes</h3>
        <div className="flex flex-wrap items-center gap-3">
          <Badge size="sm">Small</Badge>
          <Badge size="default">Default</Badge>
          <Badge size="lg">Large</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Badges in Context</h3>
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <span className="geist-text-primary">Status:</span>
            <Badge variant="success">Active</Badge>
          </div>
          <div className="flex items-center gap-2">
            <span className="geist-text-primary">Priority:</span>
            <Badge variant="error">High</Badge>
          </div>
          <div className="flex items-center gap-2">
            <span className="geist-text-primary">Version:</span>
            <Badge variant="geist">v1.0.0</Badge>
          </div>
          <div className="flex items-center gap-2">
            <span className="geist-text-primary">Environment:</span>
            <Badge variant="info">Production</Badge>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Badges with Icons</h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="geist">
            <Star className="mr-1 h-3 w-3" />
            Featured
          </Badge>
          <Badge variant="success">
            <Heart className="mr-1 h-3 w-3" />
            Liked
          </Badge>
          <Badge variant="info">
            <Clock className="mr-1 h-3 w-3" />
            Pending
          </Badge>
          <Badge variant="warning">
            <Calendar className="mr-1 h-3 w-3" />
            Scheduled
          </Badge>
        </div>
      </div>
    </div>
  )
}

// Dialog Examples
function DialogExamples() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Basic Dialog</h3>
        <Dialog>
          <DialogTrigger asChild>
            <Button>Open Dialog</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Are you absolutely sure?</DialogTitle>
              <DialogDescription>
                This action cannot be undone. This will permanently delete your account
                and remove your data from our servers.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline">Cancel</Button>
              <Button variant="destructive">Delete Account</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Dialog Variants</h3>
        <div className="flex flex-wrap gap-3">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Default Dialog</Button>
            </DialogTrigger>
            <DialogContent variant="default">
              <DialogHeader>
                <DialogTitle>Default Dialog</DialogTitle>
                <DialogDescription>
                  This is a default dialog with standard styling.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline">Cancel</Button>
                <Button>Confirm</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Secondary Dialog</Button>
            </DialogTrigger>
            <DialogContent variant="secondary">
              <DialogHeader>
                <DialogTitle>Secondary Dialog</DialogTitle>
                <DialogDescription>
                  This dialog uses secondary background styling.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline">Cancel</Button>
                <Button>Confirm</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Elevated Dialog</Button>
            </DialogTrigger>
            <DialogContent variant="elevated">
              <DialogHeader>
                <DialogTitle>Elevated Dialog</DialogTitle>
                <DialogDescription>
                  This dialog has enhanced shadow for more prominence.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline">Cancel</Button>
                <Button>Confirm</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Dialog Sizes</h3>
        <div className="flex flex-wrap gap-3">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Small Dialog</Button>
            </DialogTrigger>
            <DialogContent size="sm">
              <DialogHeader>
                <DialogTitle>Small Dialog</DialogTitle>
                <DialogDescription>
                  This is a small dialog.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button>OK</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Large Dialog</Button>
            </DialogTrigger>
            <DialogContent size="lg">
              <DialogHeader>
                <DialogTitle>Large Dialog</DialogTitle>
                <DialogDescription>
                  This is a large dialog with more space for content.
                </DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <p className="geist-text-secondary">
                  This dialog has more space for content. You can add forms, lists, or any other content here.
                  The dialog will automatically adjust its height based on the content.
                </p>
              </div>
              <DialogFooter>
                <Button variant="outline">Cancel</Button>
                <Button>Save Changes</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Full Dialog</Button>
            </DialogTrigger>
            <DialogContent size="full">
              <DialogHeader>
                <DialogTitle>Full Size Dialog</DialogTitle>
                <DialogDescription>
                  This dialog takes up most of the viewport space.
                </DialogDescription>
              </DialogHeader>
              <div className="py-4 space-y-4">
                <p className="geist-text-secondary">
                  This is a full-size dialog that takes up most of the viewport. It's useful for complex forms
                  or detailed content that needs more space.
                </p>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium geist-text-primary">Name</label>
                    <Input placeholder="Enter your name" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium geist-text-primary">Email</label>
                    <Input type="email" placeholder="Enter your email" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline">Cancel</Button>
                <Button>Save</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium geist-text-primary mb-4">Form Dialog</h3>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add User
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
              <DialogDescription>
                Create a new user account. Fill in the details below.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium geist-text-primary">Full Name</label>
                <Input placeholder="John Doe" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium geist-text-primary">Email</label>
                <Input type="email" placeholder="john@example.com" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium geist-text-primary">Role</label>
                <div className="flex gap-2">
                  <Badge variant="geist-outline">Admin</Badge>
                  <Badge variant="geist-outline">User</Badge>
                  <Badge variant="geist-outline">Guest</Badge>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline">Cancel</Button>
              <Button>Create User</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}

export {
  ButtonExamples,
  CardExamples,
  InputExamples,
  BadgeExamples,
  DialogExamples,
}

