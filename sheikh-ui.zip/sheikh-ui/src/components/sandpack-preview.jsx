import React from 'react'
import { Sandpack } from '@codesandbox/sandpack-react'
import { githubLight } from '@codesandbox/sandpack-themes'

const SandpackPreview = ({ 
  code, 
  dependencies = {}, 
  template = 'react',
  showPreview = true,
  showCode = true,
  height = '400px'
}) => {
  const files = {
    '/App.js': {
      code: code,
      active: true
    },
    '/styles.css': {
      code: `
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  margin: 0;
  padding: 20px;
}

.App {
  text-align: center;
}
      `
    }
  }

  const customSetup = {
    dependencies: {
      'react': '^18.0.0',
      'react-dom': '^18.0.0',
      'lucide-react': '^0.263.1',
      'class-variance-authority': '^0.7.0',
      'clsx': '^2.0.0',
      'tailwind-merge': '^1.14.0',
      '@radix-ui/react-slot': '^1.0.2',
      ...dependencies
    }
  }

  return (
    <div className="border rounded-lg overflow-hidden">
      <Sandpack
        template={template}
        files={files}
        customSetup={customSetup}
        theme={githubLight}
        options={{
          showNavigator: false,
          showTabs: showCode,
          showLineNumbers: true,
          showInlineErrors: true,
          wrapContent: true,
          editorHeight: height,
          layout: showPreview && showCode ? 'preview' : showCode ? 'code' : 'preview'
        }}
      />
    </div>
  )
}

export default SandpackPreview

