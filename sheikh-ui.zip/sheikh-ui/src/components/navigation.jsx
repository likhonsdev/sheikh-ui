import React, { useState } from 'react'
import { Button } from '../registry/components/button'
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from '../registry/components/menu'
import { Badge } from '../registry/components/badge'
import { 
  Home, 
  BookOpen, 
  Layers, 
  BarChart3, 
  Palette, 
  Settings,
  FileText,
  Download,
  Code,
  Blocks,
  Figma,
  Github,
  Menu,
  X
} from 'lucide-react'

const navigationItems = {
  home: {
    title: "Home",
    href: "/",
    icon: Home
  },
  docs: {
    title: "Docs",
    icon: BookOpen,
    items: [
      {
        title: "Get Started",
        items: [
          { title: "Introduction", href: "/docs", description: "Re-usable components built using Radix UI and Tailwind CSS." },
          { title: "Installation", href: "/docs/installation", description: "How to install dependencies and structure your app." },
          { title: "components.json", href: "/docs/components-json", description: "Configuration for your project." },
          { title: "Theming", href: "/docs/theming", description: "Using CSS variables or Tailwind CSS for theming." },
          { title: "Dark Mode", href: "/docs/dark-mode", description: "Adding dark mode to your site." },
          { title: "CLI", href: "/docs/cli", description: "Use the CLI to add components to your project." },
          { title: "Monorepo", href: "/docs/monorepo", description: "How to use in a monorepo." },
        ]
      },
      {
        title: "Community",
        items: [
          { title: "Open in v0", href: "/docs/v0", description: "Use v0 to build with sheikh-ui." },
          { title: "JavaScript", href: "/docs/javascript", description: "How to use sheikh-ui with JavaScript." },
          { title: "Blocks", href: "/docs/blocks", description: "Building blocks for your app." },
          { title: "Figma", href: "/docs/figma", description: "Figma design system." },
          { title: "Changelog", href: "/docs/changelog", description: "Latest updates and changes." },
          { title: "Legacy Docs", href: "/docs/legacy", description: "Previous version documentation." },
        ]
      }
    ]
  },
  components: {
    title: "Components",
    icon: Layers,
    items: [
      {
        title: "Layout",
        items: [
          { title: "Aspect Ratio", href: "/docs/components/aspect-ratio", description: "Displays content within a desired ratio." },
          { title: "Card", href: "/docs/components/card", description: "Displays a card with header, content, and footer." },
          { title: "Separator", href: "/docs/components/separator", description: "Visually or semantically separates content." },
          { title: "Skeleton", href: "/docs/components/skeleton", description: "Use to show a placeholder while content is loading." },
        ]
      },
      {
        title: "Navigation",
        items: [
          { title: "Breadcrumb", href: "/docs/components/breadcrumb", description: "Displays the path to the current resource." },
          { title: "Context Menu", href: "/docs/components/context-menu", description: "Displays a menu to the user triggered by right-click." },
          { title: "Dropdown Menu", href: "/docs/components/dropdown-menu", description: "Displays a menu to the user triggered by a button." },
          { title: "Menubar", href: "/docs/components/menubar", description: "A visually persistent menu common in desktop applications." },
          { title: "Navigation Menu", href: "/docs/components/navigation-menu", description: "A collection of links for navigating websites." },
          { title: "Pagination", href: "/docs/components/pagination", description: "Pagination with page navigation, next and previous links." },
        ]
      },
      {
        title: "Forms",
        items: [
          { title: "Button", href: "/docs/components/button", description: "Displays a button or a component that looks like a button." },
          { title: "Checkbox", href: "/docs/components/checkbox", description: "A control that allows the user to toggle between checked and not checked." },
          { title: "Input", href: "/docs/components/input", description: "Displays a form input field or a component that looks like an input field." },
          { title: "Label", href: "/docs/components/label", description: "Renders an accessible label associated with controls." },
          { title: "Radio Group", href: "/docs/components/radio-group", description: "A set of checkable buttons—known as radio buttons." },
          { title: "Select", href: "/docs/components/select", description: "Displays a list of options for the user to pick from." },
          { title: "Switch", href: "/docs/components/switch", description: "A control that allows the user to toggle between checked and not checked." },
          { title: "Textarea", href: "/docs/components/textarea", description: "Displays a form textarea or a component that looks like a textarea." },
        ]
      },
      {
        title: "Feedback",
        items: [
          { title: "Alert", href: "/docs/components/alert", description: "Displays a callout for user attention." },
          { title: "Alert Dialog", href: "/docs/components/alert-dialog", description: "A modal dialog that interrupts the user." },
          { title: "Badge", href: "/docs/components/badge", description: "Displays a badge or a component that looks like a badge." },
          { title: "Dialog", href: "/docs/components/dialog", description: "A window overlaid on either the primary window." },
          { title: "Progress", href: "/docs/components/progress", description: "Displays an indicator showing the completion progress." },
          { title: "Toast", href: "/docs/components/toast", description: "A succinct message that is displayed temporarily." },
          { title: "Tooltip", href: "/docs/components/tooltip", description: "A popup that displays information related to an element." },
        ]
      },
      {
        title: "Data Display",
        items: [
          { title: "Avatar", href: "/docs/components/avatar", description: "An image element with a fallback for representing the user." },
          { title: "Calendar", href: "/docs/components/calendar", description: "A date field component that allows users to enter and edit date." },
          { title: "Data Table", href: "/docs/components/data-table", description: "Powerful table and datagrids built using TanStack Table." },
          { title: "Table", href: "/docs/components/table", description: "A responsive table component." },
        ]
      }
    ]
  },
  blocks: {
    title: "Blocks",
    icon: Blocks,
    badge: "New"
  },
  charts: {
    title: "Charts",
    icon: BarChart3,
    badge: "New"
  },
  themes: {
    title: "Themes",
    icon: Palette
  },
  colors: {
    title: "Colors",
    icon: Settings
  }
}

const installationMethods = [
  { title: "Next.js", href: "/docs/installation/nextjs", description: "Install and configure Next.js." },
  { title: "Vite", href: "/docs/installation/vite", description: "Install and configure Vite." },
  { title: "Laravel", href: "/docs/installation/laravel", description: "Install and configure Laravel." },
  { title: "React Router", href: "/docs/installation/react-router", description: "Install and configure React Router." },
  { title: "Remix", href: "/docs/installation/remix", description: "Install and configure Remix." },
  { title: "Astro", href: "/docs/installation/astro", description: "Install and configure Astro." },
  { title: "TanStack Start", href: "/docs/installation/tanstack-start", description: "Install and configure TanStack Start." },
  { title: "TanStack Router", href: "/docs/installation/tanstack-router", description: "Install and configure TanStack Router." },
  { title: "Manual Installation", href: "/docs/installation/manual", description: "Manually add to your project." },
]

const darkModeGuides = [
  { title: "Dark Mode", href: "/docs/dark-mode", description: "Adding dark mode to your site." },
  { title: "Next.js", href: "/docs/dark-mode/nextjs", description: "Dark mode with Next.js." },
  { title: "Vite", href: "/docs/dark-mode/vite", description: "Dark mode with Vite." },
  { title: "Astro", href: "/docs/dark-mode/astro", description: "Dark mode with Astro." },
  { title: "Remix", href: "/docs/dark-mode/remix", description: "Dark mode with Remix." },
]

export function MainNavigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="border-b geist-border geist-bg-primary">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-md geist-bg-primary border geist-border flex items-center justify-center">
                <span className="text-sm font-bold geist-text-primary">S</span>
              </div>
              <span className="text-xl font-bold geist-text-primary">sheikh-ui</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <NavigationMenu>
              <NavigationMenuList>
                {/* Home */}
                <NavigationMenuItem>
                  <NavigationMenuLink
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md geist-bg-primary px-4 py-2 text-sm font-medium geist-transition hover:geist-bg-secondary focus:geist-bg-secondary focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                    href="/"
                  >
                    <Home className="mr-2 h-4 w-4" />
                    Home
                  </NavigationMenuLink>
                </NavigationMenuItem>

                {/* Docs */}
                <NavigationMenuItem>
                  <NavigationMenuTrigger>
                    <BookOpen className="mr-2 h-4 w-4" />
                    Docs
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <div className="grid gap-3 p-6 md:w-[400px] lg:w-[600px] lg:grid-cols-2">
                      <div>
                        <h4 className="text-sm font-medium geist-text-primary mb-3">Get Started</h4>
                        <ul className="space-y-2">
                          {navigationItems.docs.items[0].items.map((item) => (
                            <li key={item.title}>
                              <NavigationMenuLink asChild>
                                <a
                                  className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:geist-bg-secondary focus:geist-bg-secondary"
                                  href={item.href}
                                >
                                  <div className="text-sm font-medium leading-none geist-text-primary">{item.title}</div>
                                  <p className="line-clamp-2 text-sm leading-snug geist-text-secondary">
                                    {item.description}
                                  </p>
                                </a>
                              </NavigationMenuLink>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium geist-text-primary mb-3">Community</h4>
                        <ul className="space-y-2">
                          {navigationItems.docs.items[1].items.map((item) => (
                            <li key={item.title}>
                              <NavigationMenuLink asChild>
                                <a
                                  className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:geist-bg-secondary focus:geist-bg-secondary"
                                  href={item.href}
                                >
                                  <div className="text-sm font-medium leading-none geist-text-primary">{item.title}</div>
                                  <p className="line-clamp-2 text-sm leading-snug geist-text-secondary">
                                    {item.description}
                                  </p>
                                </a>
                              </NavigationMenuLink>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                {/* Components */}
                <NavigationMenuItem>
                  <NavigationMenuTrigger>
                    <Layers className="mr-2 h-4 w-4" />
                    Components
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <div className="grid gap-3 p-6 md:w-[500px] lg:w-[800px] lg:grid-cols-3">
                      {navigationItems.components.items.map((category) => (
                        <div key={category.title}>
                          <h4 className="text-sm font-medium geist-text-primary mb-3">{category.title}</h4>
                          <ul className="space-y-2">
                            {category.items.map((item) => (
                              <li key={item.title}>
                                <NavigationMenuLink asChild>
                                  <a
                                    className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:geist-bg-secondary focus:geist-bg-secondary"
                                    href={item.href}
                                  >
                                    <div className="text-sm font-medium leading-none geist-text-primary">{item.title}</div>
                                    <p className="line-clamp-2 text-sm leading-snug geist-text-secondary">
                                      {item.description}
                                    </p>
                                  </a>
                                </NavigationMenuLink>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                {/* Blocks */}
                <NavigationMenuItem>
                  <NavigationMenuLink
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md geist-bg-primary px-4 py-2 text-sm font-medium geist-transition hover:geist-bg-secondary focus:geist-bg-secondary focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                    href="/blocks"
                  >
                    <Blocks className="mr-2 h-4 w-4" />
                    Blocks
                    <Badge variant="geist" size="sm" className="ml-2">New</Badge>
                  </NavigationMenuLink>
                </NavigationMenuItem>

                {/* Charts */}
                <NavigationMenuItem>
                  <NavigationMenuLink
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md geist-bg-primary px-4 py-2 text-sm font-medium geist-transition hover:geist-bg-secondary focus:geist-bg-secondary focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                    href="/charts"
                  >
                    <BarChart3 className="mr-2 h-4 w-4" />
                    Charts
                    <Badge variant="geist" size="sm" className="ml-2">New</Badge>
                  </NavigationMenuLink>
                </NavigationMenuItem>

                {/* Themes */}
                <NavigationMenuItem>
                  <NavigationMenuLink
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md geist-bg-primary px-4 py-2 text-sm font-medium geist-transition hover:geist-bg-secondary focus:geist-bg-secondary focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                    href="/themes"
                  >
                    <Palette className="mr-2 h-4 w-4" />
                    Themes
                  </NavigationMenuLink>
                </NavigationMenuItem>

                {/* Colors */}
                <NavigationMenuItem>
                  <NavigationMenuLink
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md geist-bg-primary px-4 py-2 text-sm font-medium geist-transition hover:geist-bg-secondary focus:geist-bg-secondary focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                    href="/colors"
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Colors
                  </NavigationMenuLink>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>

          {/* Right side actions */}
          <div className="flex items-center space-x-4">
            <Button variant="geist-ghost" size="icon" asChild>
              <a href="https://github.com/likhonsdev/sheikh-ui" target="_blank" rel="noopener noreferrer">
                <Github className="h-4 w-4" />
              </a>
            </Button>
            <Button variant="geist-outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Get Started
            </Button>
            
            {/* Mobile menu button */}
            <Button
              variant="geist-ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t geist-border py-4">
            <div className="space-y-2">
              <a href="/" className="block px-3 py-2 rounded-md text-sm font-medium geist-text-primary hover:geist-bg-secondary geist-transition">
                <Home className="inline mr-2 h-4 w-4" />
                Home
              </a>
              <a href="/docs" className="block px-3 py-2 rounded-md text-sm font-medium geist-text-primary hover:geist-bg-secondary geist-transition">
                <BookOpen className="inline mr-2 h-4 w-4" />
                Docs
              </a>
              <a href="/components" className="block px-3 py-2 rounded-md text-sm font-medium geist-text-primary hover:geist-bg-secondary geist-transition">
                <Layers className="inline mr-2 h-4 w-4" />
                Components
              </a>
              <a href="/blocks" className="block px-3 py-2 rounded-md text-sm font-medium geist-text-primary hover:geist-bg-secondary geist-transition">
                <Blocks className="inline mr-2 h-4 w-4" />
                Blocks
                <Badge variant="geist" size="sm" className="ml-2">New</Badge>
              </a>
              <a href="/charts" className="block px-3 py-2 rounded-md text-sm font-medium geist-text-primary hover:geist-bg-secondary geist-transition">
                <BarChart3 className="inline mr-2 h-4 w-4" />
                Charts
                <Badge variant="geist" size="sm" className="ml-2">New</Badge>
              </a>
              <a href="/themes" className="block px-3 py-2 rounded-md text-sm font-medium geist-text-primary hover:geist-bg-secondary geist-transition">
                <Palette className="inline mr-2 h-4 w-4" />
                Themes
              </a>
              <a href="/colors" className="block px-3 py-2 rounded-md text-sm font-medium geist-text-primary hover:geist-bg-secondary geist-transition">
                <Settings className="inline mr-2 h-4 w-4" />
                Colors
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export { installationMethods, darkModeGuides }

