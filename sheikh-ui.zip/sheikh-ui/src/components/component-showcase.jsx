import React, { useState } from 'react'
import { Button } from '../registry/components/button'
import { Badge } from '../registry/components/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../registry/components/tabs'
import SandpackPreview from './sandpack-preview'
import { Code, Copy, CheckCircle, Eye, ExternalLink } from 'lucide-react'
import { cn } from '../registry/lib/utils'

const ComponentShowcase = ({ 
  title, 
  description, 
  preview, 
  code, 
  sandpackCode,
  dependencies = {},
  category,
  installCommand
}) => {
  const [copied, setCopied] = useState(false)

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy: ', err)
    }
  }

  const copyInstallCommand = () => {
    const command = installCommand || `bunx shadcn@latest add https://ui.likhonsheikh.xyz/r/${title.toLowerCase().replace(/\s+/g, '-')}.json`
    copyToClipboard(command)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <h3 className="text-2xl font-semibold geist-text-primary">{title}</h3>
          {category && (
            <Badge variant="secondary" className="text-xs">
              {category}
            </Badge>
          )}
        </div>
        <p className="geist-text-secondary text-base leading-relaxed">{description}</p>
        
        {/* Install Command */}
        <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
          <code className="flex-1 text-sm font-mono">
            {installCommand || `bunx shadcn@latest add https://ui.likhonsheikh.xyz/r/${title.toLowerCase().replace(/\s+/g, '-')}.json`}
          </code>
          <Button
            variant="ghost"
            size="icon"
            onClick={copyInstallCommand}
            className="h-8 w-8"
          >
            {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Tabs for Preview and Code */}
      <Tabs defaultValue="preview" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Preview
          </TabsTrigger>
          <TabsTrigger value="code" className="flex items-center gap-2">
            <Code className="h-4 w-4" />
            Code
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="preview" className="mt-6">
          <div className="border rounded-lg">
            {/* Preview Area */}
            <div className="p-8 min-h-[200px] flex items-center justify-center bg-gradient-to-br from-background to-muted/20">
              {preview}
            </div>
            
            {/* Preview Footer */}
            <div className="border-t px-4 py-3 bg-muted/30">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Interactive preview
                </span>
                <Button variant="ghost" size="sm">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open in new tab
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="code" className="mt-6">
          {sandpackCode ? (
            <SandpackPreview
              code={sandpackCode}
              dependencies={dependencies}
              height="400px"
            />
          ) : (
            <div className="border rounded-lg">
              <div className="flex items-center justify-between p-4 border-b bg-muted/30">
                <span className="text-sm font-medium">Component Code</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(code)}
                >
                  {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
              </div>
              <pre className="p-4 overflow-x-auto text-sm bg-background">
                <code className="language-jsx">{code}</code>
              </pre>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* API Reference */}
      <div className="space-y-4">
        <h4 className="text-lg font-medium geist-text-primary">API Reference</h4>
        <div className="border rounded-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-muted/30">
              <tr>
                <th className="text-left p-3 font-medium">Prop</th>
                <th className="text-left p-3 font-medium">Type</th>
                <th className="text-left p-3 font-medium">Default</th>
                <th className="text-left p-3 font-medium">Description</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t">
                <td className="p-3 font-mono text-sm">className</td>
                <td className="p-3 text-sm">string</td>
                <td className="p-3 text-sm">-</td>
                <td className="p-3 text-sm">Additional CSS classes</td>
              </tr>
              <tr className="border-t">
                <td className="p-3 font-mono text-sm">children</td>
                <td className="p-3 text-sm">ReactNode</td>
                <td className="p-3 text-sm">-</td>
                <td className="p-3 text-sm">The content of the component</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default ComponentShowcase

