import React from 'react'
import { cn } from '../lib/utils'

const LoadingSpinner = React.forwardRef(({ 
  className, 
  variant = 'default',
  size = 'default',
  color = 'blue',
  ...props 
}, ref) => {
  const sizeVariants = {
    sm: 'w-4 h-4',
    default: 'w-6 h-6',
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  }

  const colorVariants = {
    blue: 'border-blue-600',
    purple: 'border-purple-600',
    green: 'border-green-600',
    red: 'border-red-600',
    orange: 'border-orange-600',
    pink: 'border-pink-600',
    gray: 'border-gray-600'
  }

  const variants = {
    default: (
      <div
        ref={ref}
        className={cn(
          'animate-spin rounded-full border-2 border-gray-300',
          `border-t-${color}-600`,
          sizeVariants[size],
          className
        )}
        {...props}
      />
    ),
    
    dots: (
      <div
        ref={ref}
        className={cn('flex space-x-1', className)}
        {...props}
      >
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className={cn(
              'rounded-full animate-pulse',
              sizeVariants[size].replace('w-', 'w-').replace('h-', 'h-'),
              `bg-${color}-600`
            )}
            style={{
              animationDelay: `${i * 0.2}s`,
              animationDuration: '1.4s'
            }}
          />
        ))}
      </div>
    ),

    pulse: (
      <div
        ref={ref}
        className={cn(
          'rounded-full animate-ping',
          sizeVariants[size],
          `bg-${color}-600`,
          className
        )}
        {...props}
      />
    ),

    bars: (
      <div
        ref={ref}
        className={cn('flex items-end space-x-1', className)}
        {...props}
      >
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={cn(
              'animate-pulse rounded-sm',
              size === 'sm' ? 'w-1 h-3' : size === 'lg' ? 'w-2 h-6' : size === 'xl' ? 'w-3 h-8' : 'w-1.5 h-4',
              `bg-${color}-600`
            )}
            style={{
              animationDelay: `${i * 0.15}s`,
              animationDuration: '1.2s'
            }}
          />
        ))}
      </div>
    ),

    ring: (
      <div
        ref={ref}
        className={cn(
          'animate-spin rounded-full border-4 border-gray-200',
          `border-l-${color}-600`,
          sizeVariants[size],
          className
        )}
        {...props}
      />
    ),

    gradient: (
      <div
        ref={ref}
        className={cn(
          'animate-spin rounded-full border-4 border-transparent bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-border',
          sizeVariants[size],
          className
        )}
        style={{
          background: `conic-gradient(from 0deg, transparent, ${color === 'blue' ? '#3b82f6' : color === 'purple' ? '#8b5cf6' : color === 'green' ? '#10b981' : '#ef4444'})`
        }}
        {...props}
      >
        <div className="absolute inset-1 bg-white rounded-full" />
      </div>
    )
  }

  return variants[variant] || variants.default
})

LoadingSpinner.displayName = 'LoadingSpinner'

export { LoadingSpinner }

