import * as React from "react"
import { cva } from "class-variance-authority"
import { cn } from "../lib/utils"

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default:
          "border-transparent bg-primary text-primary-foreground hover:bg-primary/80 geist-transition",
        secondary:
          "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80 geist-transition",
        destructive:
          "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80 geist-transition",
        outline: "text-foreground geist-border geist-transition",
        // Geist-specific variants
        geist: "geist-bg-secondary geist-text-primary geist-border geist-transition",
        "geist-filled": "geist-bg-primary geist-text-primary border-none geist-transition",
        "geist-outline": "border geist-border geist-text-primary bg-transparent geist-transition",
        "geist-ghost": "geist-text-secondary bg-transparent border-none geist-transition",
        success: "bg-green-100 text-green-800 border-green-200 geist-transition",
        warning: "bg-yellow-100 text-yellow-800 border-yellow-200 geist-transition",
        error: "bg-red-100 text-red-800 border-red-200 geist-transition",
        info: "bg-blue-100 text-blue-800 border-blue-200 geist-transition",
      },
      size: {
        sm: "px-2 py-0.5 text-xs geist-radius-xs",
        default: "px-2.5 py-0.5 text-xs geist-radius-sm",
        lg: "px-3 py-1 text-sm geist-radius",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Badge = React.forwardRef(({ className, variant, size, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn(badgeVariants({ variant, size }), className)}
      {...props}
    />
  )
})
Badge.displayName = "Badge"

export { Badge, badgeVariants }

