import React from 'react'
import { cn } from '../lib/utils'

const AnimatedCard = React.forwardRef(({ 
  className, 
  children,
  variant = 'hover-lift',
  glowColor = 'blue',
  ...props 
}, ref) => {
  const variants = {
    'hover-lift': 'hover:scale-105 hover:-translate-y-2 hover:shadow-2xl',
    'hover-tilt': 'hover:rotate-1 hover:scale-105 hover:shadow-xl',
    'hover-glow': cn(
      'hover:shadow-2xl transition-all duration-300',
      glowColor === 'blue' && 'hover:shadow-blue-500/25',
      glowColor === 'purple' && 'hover:shadow-purple-500/25',
      glowColor === 'green' && 'hover:shadow-green-500/25',
      glowColor === 'red' && 'hover:shadow-red-500/25',
      glowColor === 'orange' && 'hover:shadow-orange-500/25'
    ),
    'hover-border': 'hover:border-blue-500 hover:shadow-lg border-2 border-transparent',
    'glass-morph': 'bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 hover:border-white/30',
    'neon-border': cn(
      'border-2 hover:shadow-2xl transition-all duration-300',
      glowColor === 'blue' && 'border-blue-500/50 hover:border-blue-400 hover:shadow-blue-500/50',
      glowColor === 'purple' && 'border-purple-500/50 hover:border-purple-400 hover:shadow-purple-500/50',
      glowColor === 'green' && 'border-green-500/50 hover:border-green-400 hover:shadow-green-500/50',
      glowColor === 'red' && 'border-red-500/50 hover:border-red-400 hover:shadow-red-500/50'
    ),
    'gradient-border': 'bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 p-[2px] hover:p-[3px] transition-all duration-300',
    'flip-3d': 'hover:rotateY-12 hover:rotateX-12 transform-gpu perspective-1000 hover:shadow-2xl',
    'pulse-glow': cn(
      'animate-pulse hover:animate-none transition-all duration-300',
      glowColor === 'blue' && 'shadow-lg shadow-blue-500/25 hover:shadow-2xl hover:shadow-blue-500/50',
      glowColor === 'purple' && 'shadow-lg shadow-purple-500/25 hover:shadow-2xl hover:shadow-purple-500/50'
    )
  }

  const isGradientBorder = variant === 'gradient-border'

  const cardContent = (
    <div
      className={cn(
        'rounded-lg p-6 transition-all duration-300 ease-in-out',
        !isGradientBorder && 'bg-white shadow-md',
        isGradientBorder && 'bg-white rounded-lg h-full w-full',
        !isGradientBorder && variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </div>
  )

  if (isGradientBorder) {
    return (
      <div
        ref={ref}
        className={cn(
          'rounded-lg transition-all duration-300 ease-in-out',
          variants[variant]
        )}
      >
        {cardContent}
      </div>
    )
  }

  return (
    <div ref={ref}>
      {cardContent}
    </div>
  )
})

AnimatedCard.displayName = 'AnimatedCard'

// Additional card variants
const GlowCard = React.forwardRef(({ 
  className, 
  children,
  glowColor = 'blue',
  intensity = 'medium',
  ...props 
}, ref) => {
  const intensityVariants = {
    low: 'shadow-lg',
    medium: 'shadow-xl',
    high: 'shadow-2xl'
  }

  const glowVariants = {
    blue: 'shadow-blue-500/25 hover:shadow-blue-500/50',
    purple: 'shadow-purple-500/25 hover:shadow-purple-500/50',
    green: 'shadow-green-500/25 hover:shadow-green-500/50',
    red: 'shadow-red-500/25 hover:shadow-red-500/50',
    orange: 'shadow-orange-500/25 hover:shadow-orange-500/50',
    pink: 'shadow-pink-500/25 hover:shadow-pink-500/50'
  }

  return (
    <div
      ref={ref}
      className={cn(
        'bg-white rounded-lg p-6 transition-all duration-300 ease-in-out hover:scale-105',
        intensityVariants[intensity],
        glowVariants[glowColor],
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
})

GlowCard.displayName = 'GlowCard'

const FlipCard = React.forwardRef(({ 
  className, 
  frontContent,
  backContent,
  ...props 
}, ref) => {
  return (
    <div
      ref={ref}
      className={cn(
        'group relative w-full h-64 perspective-1000',
        className
      )}
      {...props}
    >
      <div className="relative w-full h-full transition-transform duration-700 transform-style-preserve-3d group-hover:rotate-y-180">
        {/* Front */}
        <div className="absolute inset-0 w-full h-full backface-hidden bg-white rounded-lg shadow-lg p-6 flex items-center justify-center">
          {frontContent}
        </div>
        
        {/* Back */}
        <div className="absolute inset-0 w-full h-full backface-hidden bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg shadow-lg p-6 flex items-center justify-center rotate-y-180 text-white">
          {backContent}
        </div>
      </div>
    </div>
  )
})

FlipCard.displayName = 'FlipCard'

export { AnimatedCard, GlowCard, FlipCard }

