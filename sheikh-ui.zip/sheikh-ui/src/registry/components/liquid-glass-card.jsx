import React from 'react'
import { cn } from '../lib/utils'

const LiquidGlassCard = React.forwardRef(({ 
  className, 
  children, 
  variant = 'default',
  blur = 'md',
  ...props 
}, ref) => {
  const variants = {
    default: 'bg-white/10 border-white/20',
    dark: 'bg-black/10 border-black/20',
    colored: 'bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20'
  }

  const blurLevels = {
    sm: 'backdrop-blur-sm',
    md: 'backdrop-blur-md',
    lg: 'backdrop-blur-lg',
    xl: 'backdrop-blur-xl'
  }

  return (
    <div
      ref={ref}
      className={cn(
        'relative overflow-hidden rounded-xl border shadow-lg',
        'backdrop-saturate-150',
        blurLevels[blur],
        variants[variant],
        'transition-all duration-300 hover:shadow-xl hover:scale-[1.02]',
        'before:absolute before:inset-0 before:rounded-xl',
        'before:bg-gradient-to-br before:from-white/20 before:via-transparent before:to-transparent',
        'before:opacity-50 before:transition-opacity before:duration-300',
        'hover:before:opacity-70',
        className
      )}
      {...props}
    >
      <div className="relative z-10 p-6">
        {children}
      </div>
      
      {/* Animated liquid effect */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute -top-4 -left-4 w-24 h-24 bg-gradient-to-br from-blue-400/30 to-purple-400/30 rounded-full blur-xl animate-pulse" />
        <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-pink-400/20 to-orange-400/20 rounded-full blur-xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-gradient-to-br from-green-400/20 to-blue-400/20 rounded-full blur-lg animate-pulse delay-500" />
      </div>
    </div>
  )
})

LiquidGlassCard.displayName = 'LiquidGlassCard'

export { LiquidGlassCard }

