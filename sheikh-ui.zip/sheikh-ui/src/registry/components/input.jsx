import * as React from "react"
import { cva } from "class-variance-authority"
import { cn } from "../lib/utils"

const inputVariants = cva(
  "flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "geist-border geist-bg-primary geist-text-primary geist-transition",
        filled: "geist-bg-secondary geist-border geist-text-primary geist-transition",
        ghost: "border-none geist-bg-secondary geist-text-primary geist-transition",
        outline: "border-2 geist-border bg-transparent geist-text-primary geist-transition",
      },
      size: {
        sm: "h-8 px-2 text-xs geist-radius-sm",
        default: "h-10 px-3 text-sm geist-radius",
        lg: "h-12 px-4 text-base geist-radius-lg",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Input = React.forwardRef(({ className, type, variant, size, ...props }, ref) => {
  return (
    <input
      type={type}
      className={cn(inputVariants({ variant, size }), className)}
      ref={ref}
      {...props}
    />
  )
})
Input.displayName = "Input"

const InputGroup = React.forwardRef(({ className, children, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("relative flex items-center", className)}
    {...props}
  >
    {children}
  </div>
))
InputGroup.displayName = "InputGroup"

const InputLeftElement = React.forwardRef(({ className, children, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("absolute left-3 flex items-center geist-text-secondary", className)}
    {...props}
  >
    {children}
  </div>
))
InputLeftElement.displayName = "InputLeftElement"

const InputRightElement = React.forwardRef(({ className, children, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("absolute right-3 flex items-center geist-text-secondary", className)}
    {...props}
  >
    {children}
  </div>
))
InputRightElement.displayName = "InputRightElement"

export { Input, InputGroup, InputLeftElement, InputRightElement, inputVariants }

