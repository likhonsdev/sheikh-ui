import React, { useState, useRef, useEffect } from 'react'
import { cn } from '../lib/utils'
import { Button } from './button'

const ParticleButton = React.forwardRef(({ 
  className, 
  children, 
  variant = 'default',
  particleCount = 20,
  particleColor = '#3b82f6',
  ...props 
}, ref) => {
  const [particles, setParticles] = useState([])
  const [isAnimating, setIsAnimating] = useState(false)
  const buttonRef = useRef(null)

  const createParticles = (event) => {
    if (isAnimating) return
    
    setIsAnimating(true)
    const rect = buttonRef.current.getBoundingClientRect()
    const centerX = rect.width / 2
    const centerY = rect.height / 2
    
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: centerX,
      y: centerY,
      vx: (Math.random() - 0.5) * 8,
      vy: (Math.random() - 0.5) * 8,
      life: 1,
      decay: Math.random() * 0.02 + 0.02
    }))
    
    setParticles(newParticles)
    
    setTimeout(() => {
      setParticles([])
      setIsAnimating(false)
    }, 1000)
  }

  useEffect(() => {
    if (particles.length === 0) return

    const interval = setInterval(() => {
      setParticles(prev => 
        prev.map(particle => ({
          ...particle,
          x: particle.x + particle.vx,
          y: particle.y + particle.vy,
          life: particle.life - particle.decay,
          vy: particle.vy + 0.1 // gravity
        })).filter(particle => particle.life > 0)
      )
    }, 16)

    return () => clearInterval(interval)
  }, [particles])

  return (
    <Button
      ref={buttonRef}
      className={cn(
        'relative overflow-hidden',
        className
      )}
      variant={variant}
      onClick={createParticles}
      {...props}
    >
      {children}
      
      {/* Particles */}
      {particles.map(particle => (
        <div
          key={particle.id}
          className="absolute w-1 h-1 rounded-full pointer-events-none"
          style={{
            left: particle.x,
            top: particle.y,
            backgroundColor: particleColor,
            opacity: particle.life,
            transform: `scale(${particle.life})`
          }}
        />
      ))}
    </Button>
  )
})

ParticleButton.displayName = 'ParticleButton'

export { ParticleButton }

