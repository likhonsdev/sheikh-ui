import React from 'react'
import { cn } from '../lib/utils'

const ShimmerText = React.forwardRef(({ 
  className, 
  children, 
  shimmerColor = 'from-blue-400 via-purple-400 to-pink-400',
  speed = 'slow',
  ...props 
}, ref) => {
  const speeds = {
    slow: 'animate-[shimmer_3s_ease-in-out_infinite]',
    medium: 'animate-[shimmer_2s_ease-in-out_infinite]',
    fast: 'animate-[shimmer_1s_ease-in-out_infinite]'
  }

  return (
    <span
      ref={ref}
      className={cn(
        'relative inline-block bg-gradient-to-r bg-clip-text text-transparent',
        shimmerColor,
        speeds[speed],
        className
      )}
      {...props}
    >
      {children}
      <style jsx>{`
        @keyframes shimmer {
          0% {
            background-position: -200% center;
          }
          100% {
            background-position: 200% center;
          }
        }
      `}</style>
    </span>
  )
})

ShimmerText.displayName = 'ShimmerText'

export { ShimmerText }

