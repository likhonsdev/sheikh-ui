import React, { useState } from 'react'
import { cn } from '../lib/utils'

const ToggleSwitch = React.forwardRef(({ 
  className, 
  checked: controlledChecked,
  onCheckedChange,
  variant = 'default',
  size = 'default',
  disabled = false,
  label,
  ...props 
}, ref) => {
  const [internalChecked, setInternalChecked] = useState(false)
  const checked = controlledChecked !== undefined ? controlledChecked : internalChecked

  const handleToggle = () => {
    if (disabled) return
    
    const newChecked = !checked
    if (controlledChecked === undefined) {
      setInternalChecked(newChecked)
    }
    onCheckedChange?.(newChecked)
  }

  const sizeVariants = {
    sm: 'w-8 h-4',
    default: 'w-11 h-6',
    lg: 'w-14 h-8'
  }

  const thumbSizeVariants = {
    sm: 'w-3 h-3',
    default: 'w-5 h-5',
    lg: 'w-6 h-6'
  }

  const variants = {
    default: {
      track: checked 
        ? 'bg-blue-600 border-blue-600' 
        : 'bg-gray-200 border-gray-200',
      thumb: 'bg-white shadow-md'
    },
    neon: {
      track: checked 
        ? 'bg-gradient-to-r from-blue-500 to-purple-600 border-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.5)]' 
        : 'bg-gray-700 border-gray-600',
      thumb: checked 
        ? 'bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)]' 
        : 'bg-gray-300'
    },
    gradient: {
      track: checked 
        ? 'bg-gradient-to-r from-pink-500 to-orange-500 border-pink-400' 
        : 'bg-gray-200 border-gray-200',
      thumb: 'bg-white shadow-lg'
    },
    minimal: {
      track: checked 
        ? 'bg-black border-black' 
        : 'bg-gray-100 border-gray-300',
      thumb: 'bg-white shadow-sm'
    }
  }

  const currentVariant = variants[variant]

  return (
    <div className={cn('flex items-center gap-3', className)}>
      <button
        ref={ref}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={handleToggle}
        className={cn(
          'relative inline-flex items-center rounded-full border-2 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2',
          sizeVariants[size],
          currentVariant.track,
          disabled && 'opacity-50 cursor-not-allowed',
          !disabled && 'cursor-pointer hover:scale-105'
        )}
        {...props}
      >
        <span
          className={cn(
            'inline-block rounded-full transition-all duration-300 ease-in-out transform',
            thumbSizeVariants[size],
            currentVariant.thumb,
            checked 
              ? size === 'sm' ? 'translate-x-4' : size === 'lg' ? 'translate-x-6' : 'translate-x-5'
              : 'translate-x-0.5'
          )}
        />
      </button>
      
      {label && (
        <label 
          className={cn(
            'text-sm font-medium cursor-pointer select-none',
            disabled && 'opacity-50 cursor-not-allowed'
          )}
          onClick={!disabled ? handleToggle : undefined}
        >
          {label}
        </label>
      )}
    </div>
  )
})

ToggleSwitch.displayName = 'ToggleSwitch'

export { ToggleSwitch }

