import React from 'react'
import { cn } from '../lib/utils'
import { Button } from './button'

const GradientButton = React.forwardRef(({ 
  className, 
  children, 
  variant = 'sunset',
  size = 'default',
  animated = true,
  ...props 
}, ref) => {
  const gradientVariants = {
    sunset: 'bg-gradient-to-r from-orange-400 via-red-500 to-pink-500 hover:from-orange-500 hover:via-red-600 hover:to-pink-600',
    ocean: 'bg-gradient-to-r from-blue-400 via-blue-500 to-blue-600 hover:from-blue-500 hover:via-blue-600 hover:to-blue-700',
    forest: 'bg-gradient-to-r from-green-400 via-green-500 to-emerald-600 hover:from-green-500 hover:via-green-600 hover:to-emerald-700',
    purple: 'bg-gradient-to-r from-purple-400 via-purple-500 to-indigo-600 hover:from-purple-500 hover:via-purple-600 hover:to-indigo-700',
    rainbow: 'bg-gradient-to-r from-red-400 via-yellow-400 via-green-400 via-blue-400 to-purple-400 hover:from-red-500 hover:via-yellow-500 hover:via-green-500 hover:via-blue-500 hover:to-purple-500',
    gold: 'bg-gradient-to-r from-yellow-400 via-yellow-500 to-orange-500 hover:from-yellow-500 hover:via-yellow-600 hover:to-orange-600'
  }

  return (
    <Button
      ref={ref}
      className={cn(
        'relative overflow-hidden text-white border-0 transition-all duration-300 ease-in-out',
        'shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95',
        animated && 'bg-[length:200%_200%] animate-gradient-x',
        gradientVariants[variant],
        className
      )}
      size={size}
      {...props}
    >
      <span className="relative z-10 font-medium">{children}</span>
      
      {/* Shine effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full hover:translate-x-full transition-transform duration-700 ease-in-out" />
    </Button>
  )
})

GradientButton.displayName = 'GradientButton'

export { GradientButton }

