import React, { useState, useRef } from 'react'
import { cn } from '../lib/utils'

const FloatingInput = React.forwardRef(({ 
  className, 
  type = 'text',
  label,
  variant = 'default',
  error,
  success,
  icon: Icon,
  ...props 
}, ref) => {
  const [focused, setFocused] = useState(false)
  const [hasValue, setHasValue] = useState(false)
  const inputRef = useRef(null)

  const handleFocus = () => setFocused(true)
  const handleBlur = (e) => {
    setFocused(false)
    setHasValue(e.target.value !== '')
  }

  const variants = {
    default: {
      container: 'border-gray-300 focus-within:border-blue-500',
      label: focused || hasValue ? 'text-blue-600 -translate-y-6 scale-75' : 'text-gray-500',
      input: 'focus:outline-none'
    },
    neon: {
      container: cn(
        'border-gray-600 bg-gray-900/50 backdrop-blur-sm',
        focused ? 'border-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : '',
        error ? 'border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.3)]' : '',
        success ? 'border-green-400 shadow-[0_0_15px_rgba(34,197,94,0.3)]' : ''
      ),
      label: cn(
        'text-gray-300',
        focused || hasValue ? (
          error ? 'text-red-400 -translate-y-6 scale-75' :
          success ? 'text-green-400 -translate-y-6 scale-75' :
          'text-blue-400 -translate-y-6 scale-75'
        ) : 'text-gray-400'
      ),
      input: 'focus:outline-none bg-transparent text-white placeholder-gray-400'
    },
    minimal: {
      container: cn(
        'border-0 border-b-2 rounded-none border-gray-300 bg-transparent',
        focused ? 'border-black' : '',
        error ? 'border-red-500' : '',
        success ? 'border-green-500' : ''
      ),
      label: cn(
        focused || hasValue ? (
          error ? 'text-red-500 -translate-y-6 scale-75' :
          success ? 'text-green-500 -translate-y-6 scale-75' :
          'text-black -translate-y-6 scale-75'
        ) : 'text-gray-500'
      ),
      input: 'focus:outline-none bg-transparent'
    },
    glass: {
      container: cn(
        'border-white/20 bg-white/10 backdrop-blur-md',
        focused ? 'border-white/40 shadow-lg' : '',
        error ? 'border-red-400/50' : '',
        success ? 'border-green-400/50' : ''
      ),
      label: cn(
        'text-gray-700',
        focused || hasValue ? (
          error ? 'text-red-600 -translate-y-6 scale-75' :
          success ? 'text-green-600 -translate-y-6 scale-75' :
          'text-blue-600 -translate-y-6 scale-75'
        ) : 'text-gray-600'
      ),
      input: 'focus:outline-none bg-transparent text-gray-800 placeholder-gray-500'
    }
  }

  const currentVariant = variants[variant]

  return (
    <div className={cn('relative', className)}>
      <div className={cn(
        'relative border rounded-lg px-4 py-3 transition-all duration-200',
        currentVariant.container
      )}>
        {Icon && (
          <Icon className={cn(
            'absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 transition-colors',
            focused ? 'text-blue-500' : 'text-gray-400',
            error && 'text-red-500',
            success && 'text-green-500'
          )} />
        )}
        
        <input
          ref={ref || inputRef}
          type={type}
          className={cn(
            'w-full peer placeholder-transparent',
            Icon ? 'pl-8' : '',
            currentVariant.input
          )}
          placeholder={label}
          onFocus={handleFocus}
          onBlur={handleBlur}
          {...props}
        />
        
        {label && (
          <label className={cn(
            'absolute left-4 top-3 transition-all duration-200 pointer-events-none origin-left',
            Icon ? 'left-12' : 'left-4',
            currentVariant.label
          )}>
            {label}
          </label>
        )}
      </div>
      
      {error && (
        <p className="mt-1 text-sm text-red-600 flex items-center gap-1">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
          {error}
        </p>
      )}
      
      {success && (
        <p className="mt-1 text-sm text-green-600 flex items-center gap-1">
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          {success}
        </p>
      )}
    </div>
  )
})

FloatingInput.displayName = 'FloatingInput'

export { FloatingInput }

