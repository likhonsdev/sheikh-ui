import React, { useState } from 'react'
import { cn } from '../lib/utils'
import { Button } from './button'

const MorphingButton = React.forwardRef(({ 
  className, 
  children,
  morphTo,
  variant = 'expand',
  duration = 300,
  ...props 
}, ref) => {
  const [isHovered, setIsHovered] = useState(false)

  const variants = {
    expand: {
      base: 'relative overflow-hidden transition-all duration-300 ease-in-out',
      hover: 'px-8 bg-blue-600 text-white scale-105'
    },
    slide: {
      base: 'relative overflow-hidden transition-all duration-300 ease-in-out group',
      hover: 'text-white',
      background: 'absolute inset-0 bg-blue-600 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300 ease-in-out'
    },
    rotate: {
      base: 'relative transition-all duration-300 ease-in-out transform',
      hover: 'rotate-12 scale-110 bg-purple-600 text-white shadow-lg'
    },
    bounce: {
      base: 'relative transition-all duration-300 ease-in-out',
      hover: 'animate-bounce bg-green-600 text-white shadow-xl'
    },
    flip: {
      base: 'relative transition-all duration-500 ease-in-out transform-gpu',
      hover: 'rotateY-180 bg-red-600 text-white shadow-2xl'
    },
    pulse: {
      base: 'relative transition-all duration-300 ease-in-out',
      hover: 'animate-pulse bg-pink-600 text-white shadow-lg scale-105'
    },
    morph: {
      base: 'relative overflow-hidden transition-all duration-500 ease-in-out',
      hover: 'rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-xl scale-110'
    }
  }

  const currentVariant = variants[variant]

  return (
    <Button
      ref={ref}
      className={cn(
        currentVariant.base,
        isHovered && currentVariant.hover,
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ transitionDuration: `${duration}ms` }}
      {...props}
    >
      {variant === 'slide' && (
        <div className={currentVariant.background} />
      )}
      
      <span className="relative z-10">
        {isHovered && morphTo ? morphTo : children}
      </span>
      
      {/* Additional effects for specific variants */}
      {variant === 'expand' && (
        <div className="absolute inset-0 bg-blue-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ease-in-out origin-left" />
      )}
    </Button>
  )
})

MorphingButton.displayName = 'MorphingButton'

// Specialized morphing buttons
const LiquidButton = React.forwardRef(({ 
  className, 
  children,
  ...props 
}, ref) => {
  return (
    <Button
      ref={ref}
      className={cn(
        'relative overflow-hidden bg-blue-500 text-white transition-all duration-500 ease-in-out',
        'before:absolute before:inset-0 before:bg-blue-600 before:rounded-full before:scale-0 before:transition-transform before:duration-500',
        'hover:before:scale-150 hover:shadow-2xl hover:shadow-blue-500/50',
        className
      )}
      {...props}
    >
      <span className="relative z-10">{children}</span>
    </Button>
  )
})

LiquidButton.displayName = 'LiquidButton'

const ElasticButton = React.forwardRef(({ 
  className, 
  children,
  ...props 
}, ref) => {
  return (
    <Button
      ref={ref}
      className={cn(
        'relative transition-all duration-300 ease-in-out transform',
        'hover:scale-110 active:scale-95',
        'bg-gradient-to-r from-purple-500 to-pink-500 text-white',
        'hover:from-purple-600 hover:to-pink-600',
        'shadow-lg hover:shadow-xl hover:shadow-purple-500/50',
        'animate-pulse hover:animate-none',
        className
      )}
      {...props}
    >
      {children}
    </Button>
  )
})

ElasticButton.displayName = 'ElasticButton'

const GlitchButton = React.forwardRef(({ 
  className, 
  children,
  ...props 
}, ref) => {
  return (
    <Button
      ref={ref}
      className={cn(
        'relative bg-black text-green-400 font-mono border border-green-400',
        'hover:bg-green-400 hover:text-black transition-all duration-200',
        'before:absolute before:inset-0 before:bg-green-400 before:opacity-0',
        'hover:before:opacity-20 before:transition-opacity before:duration-200',
        'after:absolute after:inset-0 after:bg-red-500 after:opacity-0',
        'hover:after:opacity-10 after:transition-opacity after:duration-100',
        'hover:animate-pulse',
        className
      )}
      {...props}
    >
      <span className="relative z-10 hover:animate-pulse">{children}</span>
    </Button>
  )
})

GlitchButton.displayName = 'GlitchButton'

export { MorphingButton, LiquidButton, ElasticButton, GlitchButton }

