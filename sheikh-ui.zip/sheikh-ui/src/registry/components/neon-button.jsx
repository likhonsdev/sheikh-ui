import React from 'react'
import { cn } from '../lib/utils'
import { Button } from './button'

const NeonButton = React.forwardRef(({ 
  className, 
  children, 
  variant = 'neon-blue',
  size = 'default',
  ...props 
}, ref) => {
  const neonVariants = {
    'neon-blue': 'bg-blue-600 text-white border-blue-400 shadow-[0_0_20px_rgba(59,130,246,0.5)] hover:shadow-[0_0_30px_rgba(59,130,246,0.8)] hover:bg-blue-500',
    'neon-purple': 'bg-purple-600 text-white border-purple-400 shadow-[0_0_20px_rgba(147,51,234,0.5)] hover:shadow-[0_0_30px_rgba(147,51,234,0.8)] hover:bg-purple-500',
    'neon-green': 'bg-green-600 text-white border-green-400 shadow-[0_0_20px_rgba(34,197,94,0.5)] hover:shadow-[0_0_30px_rgba(34,197,94,0.8)] hover:bg-green-500',
    'neon-pink': 'bg-pink-600 text-white border-pink-400 shadow-[0_0_20px_rgba(236,72,153,0.5)] hover:shadow-[0_0_30px_rgba(236,72,153,0.8)] hover:bg-pink-500',
    'neon-cyan': 'bg-cyan-600 text-white border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.5)] hover:shadow-[0_0_30px_rgba(6,182,212,0.8)] hover:bg-cyan-500'
  }

  return (
    <Button
      ref={ref}
      className={cn(
        'relative overflow-hidden border-2 transition-all duration-300 ease-in-out',
        'before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent',
        'before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-700',
        'active:scale-95 transform',
        neonVariants[variant],
        className
      )}
      size={size}
      {...props}
    >
      <span className="relative z-10">{children}</span>
    </Button>
  )
})

NeonButton.displayName = 'NeonButton'

export { NeonButton }

