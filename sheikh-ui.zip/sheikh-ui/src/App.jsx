import React, { useState } from 'react'
import './App.css'
import { Button } from './registry/components/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './registry/components/card'
import { Badge } from './registry/components/badge'
import { Input } from './registry/components/input'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './registry/components/dialog'
import { LiquidGlassCard } from './registry/components/liquid-glass-card'
import { ParticleButton } from './registry/components/particle-button'
import { ShimmerText } from './registry/components/shimmer-text'
import { BentoGrid, BentoGridItem } from './registry/components/bento-grid'
import ComponentShowcase from './components/component-showcase'
import {
  BasicDropdownMenu,
  DropdownMenuWithCheckboxes,
  ContextMenuExample,
  NavigationMenuExample,
  MenuVariantsExample,
} from './examples/menu-examples'
import { 
  NeonButtonExamples, 
  GradientButtonExamples, 
  ToggleSwitchExamples, 
  LoadingSpinnerExamples, 
  FloatingInputExamples, 
  AnimatedCardExamples, 
  MorphingButtonExamples 
} from './examples/uiverse-examples'
import {
  Zap,
  Shield,
  Settings,
  Github,
  MessageCircle,
  Heart,
  Code,
  Palette,
  Download,
  BookOpen,
  Layers,
  Star,
  Users,
  TrendingUp,
  Activity,
  Award,
  ArrowRight,
  CheckCircle,
  Copy,
  ExternalLink,
  Menu,
  X,
  Home,
  Package,
  Database,
  BarChart3,
  ToggleLeft,
  Eye,
  Search,
  Mail,
  Lock,
  User,
  Clock,
  Sparkles,
  MousePointer,
  Type,
  Grid3X3
} from 'lucide-react'

function App() {
  const [activeSection, setActiveSection] = useState('overview')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const sections = [
    { id: 'overview', title: 'Overview', icon: Home, count: 4 },
    { id: 'installation', title: 'Installation', icon: Download, count: 3 },
    { id: 'buttons', title: 'Buttons', icon: Settings, count: 5 },
    { id: 'cards', title: 'Cards', icon: Layers, count: 2 },
    { id: 'inputs', title: 'Inputs', icon: Code, count: 7 },
    { id: 'badges', title: 'Badges', icon: Star, count: 8 },
    { id: 'dialogs', title: 'Dialogs', icon: Package, count: 3 },
    { id: 'menus', title: 'Menus', icon: Menu, count: 10 },
    { id: 'special-effects', title: 'Special Effects', icon: Sparkles, count: 1 },
    { id: 'animated-buttons', title: 'Animated Buttons', icon: MousePointer, count: 1 },
    { id: 'text-effects', title: 'Text Effects', icon: Type, count: 1 },
    { id: 'layouts', title: 'Layouts', icon: Grid3X3, count: 1 },
  ]

  const features = [
    {
      icon: Zap,
      title: "Fast & Lightweight",
      description: "Built with performance in mind using modern React patterns and optimized bundle size."
    },
    {
      icon: Shield,
      title: "Accessible",
      description: "Built on Radix UI primitives with full keyboard navigation and screen reader support."
    },
    {
      icon: Settings,
      title: "Customizable",
      description: "Copy and paste components with full control over styling and behavior."
    },
    {
      icon: Palette,
      title: "Geist Design",
      description: "Inspired by Vercel's Geist Design System for modern, clean aesthetics."
    },
    {
      icon: Code,
      title: "Developer First",
      description: "Built for developers with TypeScript support and excellent DX."
    },
    {
      icon: Heart,
      title: "Open Source",
      description: "Free and open source. Use it in your personal and commercial projects."
    }
  ]

  const stats = [
    { title: "Components", value: "50+", icon: Layers },
    { title: "Downloads", value: "10K+", icon: Download },
    { title: "GitHub Stars", value: "2.5K+", icon: Star },
    { title: "Contributors", value: "25+", icon: Users }
  ]

  // Button click handlers
  const handleGetStarted = () => {
    setActiveSection('installation')
  }

  const handleViewDocumentation = () => {
    setActiveSection('overview')
    setTimeout(() => {
      const quickStartElement = document.querySelector('[data-section="quick-start"]')
      if (quickStartElement) {
        quickStartElement.scrollIntoView({ behavior: 'smooth' })
      }
    }, 100)
  }

  const handleGitHubClick = () => {
    window.open('https://github.com/likhonsdev/sheikh-ui', '_blank')
  }

  const handleTelegramClick = () => {
    window.open('https://t.me/likhonsheikh', '_blank')
  }

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return (
          <div className="space-y-12">
            {/* Hero Section */}
            <div className="text-center space-y-6 py-12">
              <div className="space-y-4">
                <Badge variant="geist" className="mb-4">
                  <Star className="mr-1 h-3 w-3" />
                  New Release v1.0
                </Badge>
                <h1 className="text-4xl md:text-6xl font-bold geist-text-primary">
                  sheikh-ui
                </h1>
                <p className="text-xl geist-text-secondary max-w-2xl mx-auto">
                  A modern React component library inspired by Vercel's Geist Design System
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-base" onClick={handleGetStarted}>
                  <Download className="mr-2 h-5 w-5" />
                  Get Started
                </Button>
                <Button variant="outline" size="lg" className="text-base" onClick={handleViewDocumentation}>
                  <BookOpen className="mr-2 h-5 w-5" />
                  View Documentation
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {stats.map((stat) => (
                <Card key={stat.title}>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                    <stat.icon className="h-4 w-4 geist-text-secondary" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stat.value}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Features */}
            <div>
              <h2 className="text-3xl font-bold geist-text-primary text-center mb-8">
                Why Choose sheikh-ui?
              </h2>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {features.map((feature) => (
                  <Card key={feature.title}>
                    <CardHeader>
                      <div className="w-12 h-12 rounded-lg geist-bg-secondary flex items-center justify-center mb-4">
                        <feature.icon className="w-6 h-6 geist-text-primary" />
                      </div>
                      <CardTitle className="text-lg">{feature.title}</CardTitle>
                      <CardDescription>{feature.description}</CardDescription>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </div>

            {/* Quick Start */}
            <Card data-section="quick-start">
              <CardHeader>
                <CardTitle className="text-2xl">Quick Start</CardTitle>
                <CardDescription>
                  Get started with sheikh-ui in minutes. Copy and paste components into your project.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium geist-text-primary mb-2">1. Install dependencies</h4>
                  <div className="geist-bg-secondary p-4 rounded-lg font-mono text-sm flex items-center justify-between">
                    <code>npm install @radix-ui/react-* class-variance-authority clsx tailwind-merge</code>
                    <Button variant="ghost" size="icon" className="ml-2">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium geist-text-primary mb-2">2. Add component</h4>
                  <div className="geist-bg-secondary p-4 rounded-lg font-mono text-sm flex items-center justify-between">
                    <code>bunx shadcn@latest add https://ui.likhonsheikh.xyz/r/button.json</code>
                    <Button variant="ghost" size="icon" className="ml-2">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium geist-text-primary mb-2">3. Start building</h4>
                  <div className="geist-bg-secondary p-4 rounded-lg font-mono text-sm flex items-center justify-between">
                    <code>import &#123; Button &#125; from "./components/ui/button"</code>
                    <Button variant="ghost" size="icon" className="ml-2">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={() => setActiveSection('installation')}>
                  <BookOpen className="mr-2 h-4 w-4" />
                  Read Installation Guide
                </Button>
              </CardFooter>
            </Card>

            {/* Community */}
            <div className="text-center space-y-6">
              <h2 className="text-3xl font-bold geist-text-primary">
                Join the Community
              </h2>
              <p className="text-lg geist-text-secondary max-w-2xl mx-auto">
                Get help, share feedback, and connect with other developers using sheikh-ui.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="outline" onClick={handleGitHubClick}>
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" onClick={handleTelegramClick}>
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Telegram
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        )
      case 'animated-buttons':
        return (
          <div className="space-y-12">
            <div>
              <h2 className="text-3xl font-bold geist-text-primary mb-4">Animated Buttons</h2>
              <p className="text-lg geist-text-secondary mb-8">
                Interactive buttons with engaging animations and effects.
              </p>
            </div>
            
            <ComponentShowcase
              title="Particle Button"
              description="A button that creates particle explosion effects when clicked."
              category="Animated Buttons"
              preview={<ParticleButton>Click for particles!</ParticleButton>}
              code={`<ParticleButton>Click for particles!</ParticleButton>`}
              sandpackCode={`import React from 'react';
import { ParticleButton } from './components/ui/particle-button';

export default function App() {
  return (
    <div className="p-8">
      <ParticleButton>Click for particles!</ParticleButton>
    </div>
  );
}`}
            />

            <ComponentShowcase
              title="Neon Buttons"
              description="Buttons with neon glow effects and hover animations."
              category="Animated Buttons"
              preview={<NeonButtonExamples />}
              code={`import { NeonButton } from "./components/ui/neon-button"

<NeonButton variant="neon-blue">Blue Neon</NeonButton>
<NeonButton variant="neon-purple">Purple Neon</NeonButton>
<NeonButton variant="neon-green">Green Neon</NeonButton>`}
              sandpackCode={`import React from 'react';
import { NeonButton } from './components/ui/neon-button';

export default function App() {
  return (
    <div className="p-8 space-y-4">
      <NeonButton variant="neon-blue">Blue Neon</NeonButton>
      <NeonButton variant="neon-purple">Purple Neon</NeonButton>
      <NeonButton variant="neon-green">Green Neon</NeonButton>
    </div>
  );
}`}
            />

            <ComponentShowcase
              title="Gradient Buttons"
              description="Buttons with beautiful gradient backgrounds and shine effects."
              category="Animated Buttons"
              preview={<GradientButtonExamples />}
              code={`import { GradientButton } from "./components/ui/gradient-button"

<GradientButton variant="sunset">Sunset</GradientButton>
<GradientButton variant="ocean">Ocean</GradientButton>
<GradientButton variant="rainbow" animated={true}>Rainbow</GradientButton>`}
              sandpackCode={`import React from 'react';
import { GradientButton } from './components/ui/gradient-button';

export default function App() {
  return (
    <div className="p-8 space-y-4">
      <GradientButton variant="sunset">Sunset</GradientButton>
      <GradientButton variant="ocean">Ocean</GradientButton>
      <GradientButton variant="rainbow" animated={true}>Rainbow</GradientButton>
    </div>
  );
}`}
            />

            <ComponentShowcase
              title="Morphing Buttons"
              description="Buttons that transform and morph on interaction."
              category="Animated Buttons"
              preview={<MorphingButtonExamples />}
              code={`import { MorphingButton, LiquidButton, ElasticButton } from "./components/ui/morphing-button"

<MorphingButton variant="expand">Expand</MorphingButton>
<LiquidButton>Liquid Effect</LiquidButton>
<ElasticButton>Elastic</ElasticButton>`}
              sandpackCode={`import React from 'react';
import { MorphingButton, LiquidButton, ElasticButton } from './components/ui/morphing-button';

export default function App() {
  return (
    <div className="p-8 space-y-4">
      <MorphingButton variant="expand">Expand</MorphingButton>
      <LiquidButton>Liquid Effect</LiquidButton>
      <ElasticButton>Elastic</ElasticButton>
    </div>
  );
}`}
            />
          </div>
        )
      case 'special-effects':
        return (
          <div className="space-y-12">
            <div>
              <h2 className="text-3xl font-bold geist-text-primary mb-4">Special Effects</h2>
              <p className="text-lg geist-text-secondary mb-8">
                Advanced components with stunning visual effects and animations.
              </p>
            </div>
            
            <ComponentShowcase
              title="Liquid Glass Card"
              description="A glassmorphism card with liquid animation effects and backdrop blur."
              category="Special Effects"
              preview={
                <LiquidGlassCard className="w-80 h-48">
                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-white mb-2">Liquid Glass Card</h3>
                    <p className="text-white/80">This card features a beautiful glassmorphism effect with animated liquid backgrounds.</p>
                  </div>
                </LiquidGlassCard>
              }
              code={`<LiquidGlassCard className="w-80 h-48">
  <div className="p-6">
    <h3 className="text-lg font-semibold text-white mb-2">Liquid Glass Card</h3>
    <p className="text-white/80">Beautiful glassmorphism effect.</p>
  </div>
</LiquidGlassCard>`}
              sandpackCode={`import React from 'react';
import { LiquidGlassCard } from './components/ui/liquid-glass-card';

export default function App() {
  return (
    <div className="p-8">
      <LiquidGlassCard className="w-80 h-48">
        <div className="p-6">
          <h3 className="text-lg font-semibold text-white mb-2">Liquid Glass Card</h3>
          <p className="text-white/80">Beautiful glassmorphism effect.</p>
        </div>
      </LiquidGlassCard>
    </div>
  );
}`}
            />

            <ComponentShowcase
              title="Loading Spinners"
              description="Loading spinners with multiple animation variants."
              category="Special Effects"
              preview={<LoadingSpinnerExamples />}
              code={`import { LoadingSpinner } from "./components/ui/loading-spinner"

<LoadingSpinner variant="default" />
<LoadingSpinner variant="dots" />
<LoadingSpinner variant="pulse" />
<LoadingSpinner variant="gradient" />`}
              sandpackCode={`import React from 'react';
import { LoadingSpinner } from './components/ui/loading-spinner';

export default function App() {
  return (
    <div className="p-8 flex gap-8 items-center">
      <LoadingSpinner variant="default" />
      <LoadingSpinner variant="dots" />
      <LoadingSpinner variant="pulse" />
      <LoadingSpinner variant="gradient" />
    </div>
  );
}`}
            />

            <ComponentShowcase
              title="Animated Cards"
              description="Cards with hover animations and special effects."
              category="Special Effects"
              preview={<AnimatedCardExamples />}
              code={`import { AnimatedCard, GlowCard, FlipCard } from "./components/ui/animated-card"

<AnimatedCard variant="hover-lift">Hover Lift</AnimatedCard>
<GlowCard glowColor="purple">Glow Card</GlowCard>
<FlipCard frontContent="Front" backContent="Back" />`}
              sandpackCode={`import React from 'react';
import { AnimatedCard, GlowCard } from './components/ui/animated-card';

export default function App() {
  return (
    <div className="p-8 grid grid-cols-2 gap-4">
      <AnimatedCard variant="hover-lift">
        <div className="p-4 text-center">
          <h3>Hover Lift</h3>
          <p>Lifts up on hover</p>
        </div>
      </AnimatedCard>
      <GlowCard glowColor="purple">
        <div className="p-4 text-center">
          <h3>Glow Card</h3>
          <p>Beautiful glow effects</p>
        </div>
      </GlowCard>
    </div>
  );
}`}
            />
          </div>
        )
      case 'inputs':
        return (
          <div className="space-y-12">
            <div>
              <h2 className="text-3xl font-bold geist-text-primary mb-4">Input Components</h2>
              <p className="text-lg geist-text-secondary mb-8">
                Form input components with various styles and animations.
              </p>
            </div>
            
            <ComponentShowcase
              title="Floating Input"
              description="Input fields with floating label animations."
              category="Inputs"
              preview={<FloatingInputExamples />}
              code={`import { FloatingInput } from "./components/ui/floating-input"

<FloatingInput label="Email Address" type="email" />
<FloatingInput variant="neon" label="Username" />
<FloatingInput variant="glass" label="Search" />`}
              sandpackCode={`import React from 'react';
import { FloatingInput } from './components/ui/floating-input';

export default function App() {
  return (
    <div className="p-8 space-y-4">
      <FloatingInput label="Email Address" type="email" />
      <FloatingInput variant="neon" label="Username" />
      <FloatingInput variant="glass" label="Search" />
    </div>
  );
}`}
            />

            <ComponentShowcase
              title="Toggle Switch"
              description="Customizable toggle switches with multiple variants."
              category="Inputs"
              preview={<ToggleSwitchExamples />}
              code={`import { ToggleSwitch } from "./components/ui/toggle-switch"

<ToggleSwitch label="Default Switch" />
<ToggleSwitch variant="neon" label="Neon Switch" />
<ToggleSwitch variant="gradient" label="Gradient Switch" />`}
              sandpackCode={`import React from 'react';
import { ToggleSwitch } from './components/ui/toggle-switch';

export default function App() {
  return (
    <div className="p-8 space-y-4">
      <ToggleSwitch label="Default Switch" />
      <ToggleSwitch variant="neon" label="Neon Switch" />
      <ToggleSwitch variant="gradient" label="Gradient Switch" />
    </div>
  );
}`}
            />
          </div>
        )
      default:
        return (
          <div className="space-y-12">
            <div>
              <h2 className="text-3xl font-bold geist-text-primary mb-4">Coming Soon</h2>
              <p className="text-lg geist-text-secondary mb-8">
                This section is under development. More components coming soon!
              </p>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen geist-bg-primary">
      {/* Header */}
      <header className="geist-bg-primary geist-border-bottom sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <a href="/" className="text-xl font-bold geist-text-primary">
                sheikh-ui
              </a>
            </div>
            <div className="hidden md:flex items-center gap-4">
              <Button variant="ghost" size="sm">
                Documentation
              </Button>
              <Button variant="ghost" size="sm" onClick={handleGitHubClick}>
                <Github className="w-4 h-4" />
                GitHub
              </Button>
              <Button size="sm" onClick={handleGetStarted}>
                Get Started
              </Button>
            </div>
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-24">
              <nav className="space-y-1">
                <div className="text-xs font-semibold geist-text-secondary uppercase tracking-wider mb-3">
                  Components
                </div>
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors ${
                      activeSection === section.id
                        ? 'geist-bg-secondary geist-text-primary'
                        : 'geist-text-secondary hover:geist-text-primary hover:geist-bg-secondary'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <section.icon className="w-4 h-4" />
                      <span>{section.title}</span>
                    </div>
                    {section.count && (
                      <Badge variant="secondary" className="text-xs">
                        {section.count}
                      </Badge>
                    )}
                  </button>
                ))}
              </nav>
            </div>
          </aside>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden fixed inset-0 z-50 geist-bg-primary">
              <div className="flex items-center justify-between p-4 geist-border-bottom">
                <span className="text-lg font-semibold">Navigation</span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <nav className="p-4 space-y-2">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => {
                      setActiveSection(section.id)
                      setMobileMenuOpen(false)
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors ${
                      activeSection === section.id
                        ? 'geist-bg-secondary geist-text-primary'
                        : 'geist-text-secondary hover:geist-text-primary hover:geist-bg-secondary'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <section.icon className="w-4 h-4" />
                      <span>{section.title}</span>
                    </div>
                    {section.count && (
                      <Badge variant="secondary" className="text-xs">
                        {section.count}
                      </Badge>
                    )}
                  </button>
                ))}
              </nav>
            </div>
          )}

          {/* Main Content */}
          <main className="flex-1 min-w-0">
            {renderSection()}
          </main>
        </div>
      </div>

      {/* Footer */}
      <footer className="geist-bg-primary geist-border-top mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center geist-text-secondary">
            <p>Built with ❤️ by <a href="https://github.com/likhonsdev" className="geist-text-primary hover:underline">Likhon Sheikh</a></p>
            <div className="flex justify-center gap-4 mt-4">
              <a href="https://github.com/likhonsdev" className="geist-text-secondary hover:geist-text-primary">
                <Github className="w-5 h-5" />
              </a>
              <a href="https://t.me/likhonsheikh" className="geist-text-secondary hover:geist-text-primary">
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

